
var Pacientes = artifacts.require('./Pacientes.sol')

module.exports = function (deployer) {
  deployer.deploy(Pacientes)
}
