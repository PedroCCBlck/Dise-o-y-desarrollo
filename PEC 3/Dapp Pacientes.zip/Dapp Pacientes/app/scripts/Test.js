// Script de test en JavasScript para probar los contratos
//cargamos primero los artifacts de los diferentes contratos
var Pacientes = artifacts.require('../contracts/Pacientes.sol');
var Owned = artifacts.require('../contracts/Owned.sol');
var SafeMath = artifacts.require('../contracts/SafeMath.sol');

contract('Pacientes', function (accounts) {
  var Instance;
  var admin = accounts[0];
  var cuenta1 = accounts[1];
  

//Empezamos verificando que las direcciones de los diferentes contratos no son la 0

  it('Se incializa el contrato Pacientes con los valores correctos', function () {
    return Pacientes.deployed().then(function (instance) {
      PacientesInstance = instance;
      return PacientesInstance.address
    }).then(function (address) {
      assert.notEqual(address, 0x0, 'el contrato devuelve una address correcta');
      return true;
    })

  })

  //Al registrar un paciente se devuelve el resultado correcto (True)
  it('Al registrar un paciente se devuelve el resultado correcto (True)', function () {
    return Pacientes.deployed().then(function (instance) {
      PacientesInstance = instance;
      return PacientesInstance.newInfo,call( 75, 125, 50, 6, 1350, 76921472, "Medium", "B",False, admin);
    }).then(function (resultado) {
      assert.Equal(resultado, true, 'el registro se ha realizado correctamente');
      return true;
    })
  })

  //Al intentar registrar un paciente con el flag de emergencia activado no se devuelve true
  it('Al intentar registrar un paciente con el flag de emergencia activado no se devuelve true', function () {
    return Pacientes.deployed().then(function (instance) {
      PacientesInstance = instance;
      return PacientesInstance.newInfo.call( 75, 125, 50, 6, 1350, 11111111, "Medium", "B", True, admin);
    }).then(function (resultado) {
      assert.notEqual(resultado, true, 'No se ha devuelto true por estar el flag de emergencia activado');
      return true;
    })
  })

  //Al intentar registrar un paciente con el flag de emergencia activado y con la dirección 
  //de otra cuenta que no es el admin no se devuelve true
  it('Al intentar registrar un paciente con el flag de emergencia activado y con la dirección de otra cuenta que no es el admin no se devuelve true', function () {
    return Pacientes.deployed().then(function (instance) {
      PacientesInstance = instance;
      return PacientesInstance.newInfo.call( 75, 125, 50, 6, 1350, 11111111, "Medium", "B", True, cuenta1);
    }).then(function (resultado) {
      assert.notEqual(resultado, true, 'No se ha devuelto true por estar el flag de emergencia activado');
      return true;
    })
  })

  //Se recuperan los datos de forma correcta con la funcion GetInfo
  it('Al intentar recuperar los datos de un paciente se realiza de forma correcta', function () {
    return Pacientes.deployed().then(function (instance) {
      PacientesInstance = instance;
      return PacientesInstance.getInfo.call( 76921472, admin);
    }).then(function (resultado) {
      assert.Equal(resultado[7], "Medium", 'riesgo correcto');
      assert.Equal(resultado[8], "B", 'hospital correcto');
      return true;
    })
  })

 //El proceso de borrado se ejecuta de manera correcta
 it('El proceso de borrado se realiza de manera correcta', function () {
  return Pacientes.deployed().then(function (instance) {
    PacientesInstance = instance;
    return PacientesInstance.removeInfo.call(76921472 , False, admin);
  
})
})

//el balance chequeado es el correcto
it('El proceso de recuperación del saldo se realiza de manera correcta', function () {
  return Pacientes.deployed().then(function (instance) {
    PacientesInstance = instance;
    return PacientesInstance.getInfo.call(admin);
  }).then(function (resultado) {
    assert.Equal(resultado, 1000, 'importe correcto');
    return true;
  })
})

})

//

contract('Owned', function (accounts) {
  var Instance;
  var admin = accounts[0];
  var cuenta1 = accounts[1];
  

//Verificamos que el contrato devuelve el resultado correcto

  it('Se incializa el contrato Owned con los valores correctos', function () {
    return Owned.deployed().then(function (instance) {
      OwnedInstance = instance;
      return PacientesInstance.address
    }).then(function (address) {
      assert.notEqual(address, 0x0, 'el contrato devuelve una address correcta');
      return true;
    })

  })

  it('Se ejecuta bien el modifier', function () {
    return Owned.deployed().then(function (instance) {
      OwnedInstance = instance;
      return OwnedInstance.onlyOwner.call(admin);

  })

  })

  contract('SafeMath', function (accounts) {
    var Instance;
    var admin = accounts[0];
    var cuenta1 = accounts[1];
    
  
  //Verificamos que el contrato devuelve el resultado correcto
  
    it('Se incializa el contrato SafeMath con los valores correctos', function () {
      return SafeMath.deployed().then(function (instance) {
        SafeMathInstance = instance;
        return SafeMathInstance.address
      }).then(function (address) {
        assert.notEqual(address, 0x0, 'el contrato devuelve una address correcta');
        return true;
      })
  
    })
  //Verificamos que la suma la hace de manera correcta
    it('Se ejecuta bien el la función de sumar', function () {
      return SafeMath.deployed().then(function (instance) {
        SafeMathInstance = instance;
        return SafeMath.sum.call(8,2);
      }).then(function (res) {
        assert.Equal(res, 10, 'la suma se ha hecho correctamente');
        return true;
      })
  
    })
  
  //Verificamos que la resta la hace de manera correcta
  it('Se ejecuta bien el la función de sumar', function () {
    return SafeMath.deployed().then(function (instance) {
      SafeMathInstance = instance;
      return SafeMath.sub.call(8,2);
    }).then(function (res) {
      assert.Equal(res, 6, 'la resta se ha hecho correctamente');
      return true;
    })

  })


    })

  })



