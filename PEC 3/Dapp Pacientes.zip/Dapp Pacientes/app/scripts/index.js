// Importamos las librerías que necesitamos
import '../styles/app.css' //Con esta librería el frontal tiene mejor apariencia 
import { default as Web3 } from 'web3'
import { default as contract } from 'truffle-contract'

// Importamos los artifacts para crear la abstracción 
import PacientesArtifact from '../../build/contracts/Pacientes.json'


const Pacientes = contract(PacientesArtifact)

let accounts
let account

const App = { //estas son las funciones que vamos a ejecutar cuando se lance la aplicación
  start: function () {
    
    console.log("Iniciando app");
    const self = this

    
    Pacientes.setProvider(web3.currentProvider)

    
    web3.eth.getAccounts(function (err, accs) {
      if (err != null) {
        alert('Ha habido un error recuperando las cuentas')
        return
      }

      if (accs.length === 0) {
        alert("No se ha podido recuperar las cuentas.")
        return
      }
      web3.eth.getCoinbase(function (err, account) {
        console.log("entrando");
        if (err === null) {
          App.account = account;
          $("#accountAddress").html("Tu cuenta es: " + account); //Mostrar el address actual (en función del proveedor: MetaMask...)
        }
      })
      accounts = accs
      account = web3.eth.accounts[0]; 
      setInterval(function() { //Refrescar automáticamente la web en caso de cambiar de address (MetaMask)
      if (web3.eth.accounts[0] !== account) {
      account = web3.eth.accounts[0];
      window.location.reload();
      App.init();
      };
      }, 100);
      account = web3.eth.accounts[0]
      console.log(account)
      self.refreshBalance()
    })
  },


  
/*Creamos esta función para mostrar el estado en el frontend y así darle una orientación al usuario
Las llamadas a esta función las haremos desde el resto de funciones (refresh, ParadaEmergencia, newInfo...) */
  setStatus: function (message) {
    const status = document.getElementById('status')
    status.innerHTML = message
  },

  //por esta función vamos a pasar al cargar la página web y al hacer crear un registro, borrarlo o consultarlo (acciones que cuestan tokens)
  //la función nos permite chequear en el frontal el estado de la cuenta del sender
  refreshBalance: function () {
    const self = this
    const idPac = document.getElementById("idPac").value;
    console.log("Iniciando recuperar balance");
    window.alert("Refrescándose los datos del paciente")
    let meta
    Pacientes.deployed().then(function (instance) {
      meta = instance
      return meta.getBalance.call({from: account});
    }).then(function (value) {
      console.log(value);
      const balanceElement = document.getElementById('balance')
      balanceElement.innerHTML = value.valueOf()
    }).catch(function (e) {
      console.log(e)
      self.setStatus('Error recuperando el balance; ver log.')
    })
  },

  //Esta función nos va a implementar el circuit breaker utilizando el parámetro de entrada desde el frontal.
  ParadaEmergencia: function () { 
    const self = this;
    const Emergencia = document.getElementById("Emergencia").value;
    var EmergenciaBol;
    if (Emergencia=="True")
    {
      EmergenciaBol=true;
    }
    else
    {
      EmergenciaBol=false; 
    };
    this.setStatus('Cambiando el estado del interruptor de emergencia');
    let meta
    Pacientes.deployed().then(function (instance) {
      meta = instance
      return meta.CambioEstadoEmergencia.call(EmergenciaBol,{ from: account }) /*no queremos que salte la transacción por una emergencia
                                                                                por eso hacemos la llamada mediante el call*/
    }).then(function (value) {
      console.log("Estado emergencia: " + value);
      self.setStatus('Estado del interruptor de emergencia cambiado')
    }).catch(function (e) {
      console.log(e)
      self.setStatus('Error en la ejecución del cambio del estado de emergencia; ver log.')
      var htmlemergencia = $("#Emergencia").empty();
      var EmergenciaTemplate ="True";
      htmlemergencia.append(EmergenciaTemplate);
      document.getElementById("Emergencia").disabled=true; //si alguien que no es el owner intenta modificar el campo se activa la parada de emergencia

    })
  },

//Con esta función vamos a gestionar la escritura de los datos médicos de los pacientes
  newInfo: function () {
    const self = this;

    const Glucosa = document.getElementById("Glucosa").value;
    const Colesterol = document.getElementById("Colesterol").value;
    const Trigliceridos = document.getElementById("Trigliceridos").value;
    const AcidoUrico = document.getElementById("AcidoUrico").value;
    const Linfocitos = document.getElementById("Linfocitos").value;
    const PacId = document.getElementById("PacId").value;
  
    
    const RiesgoNum=(Glucosa/110)*0.3+(Colesterol/200)*0.1+(Trigliceridos/220)*0.2+(AcidoUrico/7)*0.1+(Linfocitos/4000)*0.3;
    //diseñamos un pequeño modelo de valoración del riesgo del paciente. Primero normalizamos y luego ponderamos según nuestro modelo
    var Riesgo;
    var Hospital;
    if (RiesgoNum<=0.4){
    Riesgo="Low";
    Hospital="A";
    }
    else if (RiesgoNum>0.4 && RiesgoNum<=0.7) {
      Riesgo="Medium";
      Hospital="B";

    }
    else {
    Riesgo="High";
    Hospital="C";
    }
    
    const Emergencia = document.getElementById("Emergencia").value;
    var EmergenciaBol;
    if (Emergencia=="True")
    {
      EmergenciaBol=true;
    }
    else
    {
      EmergenciaBol=false; 
    };

    this.setStatus('Iniciando transacción... (por favor espere)');
    let meta
    window.alert("Escribiendo datos del paciente")
    Pacientes.deployed().then(function (instance) {
      meta = instance
      return meta.newInfo( Glucosa, Colesterol, Trigliceridos, AcidoUrico, Linfocitos, PacId, Riesgo, Hospital,EmergenciaBol, { from: account })
    }).then(function (value) {
      console.log(value + "new info");
      console.log(value);
      //console.log("new");
      self.setStatus('Transacción completada')
      self.refreshBalance()
    }).catch(function (e) {
      console.log(e)
      self.setStatus('Error en la transacción; ver log.')
    })

  },


//esta función nos permite eliminar un registro detecrminado (direccionado mediante el identificador de paciente)
removeInfo: function () {
  const self = this;
  const idPac = document.getElementById("idPac").value;
  this.setStatus('Iniciando proceso de borrado... (por favor espere)');
  const Emergencia = document.getElementById("Emergencia").value;
    var EmergenciaBol;
    if (Emergencia=="True")
    {
      EmergenciaBol=true;
    }
    else
    {
      EmergenciaBol=false; 
    };
  let meta
  Pacientes.deployed().then(function (instance) {
    meta = instance
    return meta.removeInfo(idPac , EmergenciaBol, { from: account })
  }).then(function (value) {
    console.log(value);
    //console.log("new");
    self.setStatus('Borrado completada')
    self.refreshBalance()
  }).catch(function (e) {
    console.log(e)
    self.setStatus('Error en el borrado; ver log.')
  })
},

/*con esta función vamos a obtener los datos del riesgo y del hospital asignado del paciente (que lo pintaremos 
en la tabla creada)*/

getInfo: function () {
  const self = this;
  const idPac = document.getElementById("idPac").value;
  this.setStatus('Iniciando proceso de consulta... (por favor espere)');
  let meta
  Pacientes.deployed().then(function (instance) {
    meta = instance
    return meta.getInfo(idPac , { from: account })
    
  }).then(function () {
    meta.myPatient(idPac).then(function(value){
      var htmlpacientes = $("#PatientTable").empty();
      console.log(value + "tabla");
      console.log(value);
      var paciente = {  /*Le pasamos a la tabla los valores del riesgo del paciente (calculado con nuestro modelo)
         y el hospital asignado). La idea es que un usuario pueda ver únicamente esta información (que es menos detallada) de este paciente
          y no los indicadores médicos específicos*/
      Riesgo: value[7],
      Hospital: value[8]
      }
      var PacienteTemplate =
      "<tr><th>" + paciente.Riesgo +
      "</td><td>" + paciente.Hospital +
      "</td></tr>";
      htmlpacientes.append(PacienteTemplate);
      console.log(value);
      self.setStatus('Consulta completada')
      self.refreshBalance()
    })

    

  }).catch(function (e) {
    console.log(e)
    self.setStatus('Error en la consulta; ver log.')
  })
}



}
window.App = App


//módulo que nos permite detectar que la carga del metamask (que es la aplicación que permite la 
//del browser con el nodo) se ha realizado correctamente
window.addEventListener('load', function () {
  
  if (typeof web3 !== 'undefined') {
    console.warn(
      'La carga del web 3 se ha realizado correctamente'
    )
    // Use Mist/MetaMask's provider
    window.web3 = new Web3(web3.currentProvider)
  } else {
    console.warn(
      'La carga del web 3 no se ha realizado correctamente'
    )
    window.web3 = new Web3(new Web3.providers.HttpProvider('http://127.0.0.1:7545'))
  }

  App.start()
})



