// Script de test en JavasScript para probar los contratos
//cargamos primero los artifacts de los diferentes contratos
var Pacientes = artifacts.require('../contracts/Pacientes.sol');
var Owned = artifacts.require('../contracts/Owned.sol');
var SafeMath = artifacts.require('../contracts/SafeMath.sol');

contract('Pacientes', function (accounts) {
  var Instance;
  var admin = accounts[0];
  var cuenta1 = accounts[1];
  

//Empezamos verificando que las direcciones de los diferentes contratos no son la 0

  it('Se incializa el contrato Pacientes con los valores correctos', function () {
    return Pacientes.deployed().then(function (instance) {
      var PacientesInstance = instance;
      return PacientesInstance.address
    }).then(function (address) {
      assert.notEqual(address, 0x0, 'el contrato devuelve una address correcta');
      return true;
    })

  })


  //Al registrar un paciente se devuelve el resultado correcto (True)
  it('Al registrar un paciente se devuelve el resultado correcto (True)', function () {
    return Pacientes.deployed().then(function (instance) {
      var PacientesInstance = instance;
      return PacientesInstance.newInfo( 75, 125, 50, 6, 1350, 76921472, "Medium", "B",false);
    }).then(function (resultado) {
      assert.equal(resultado.logs.length, 1, 'Se registra el evento');
      assert.equal(resultado.logs[0].event, 'Transfer', 'Debe generarse le evento Tramsfer');
    })
  })



  //Al intentar registrar un paciente con el flag de emergencia activado no se devuelve true
  it('Al intentar registrar un paciente con el flag de emergencia activado no se devuelve true', function () {
    return Pacientes.deployed().then(function (instance) {
      var PacientesInstance = instance;
      return PacientesInstance.newInfo( 75, 125, 50, 6, 1350, 11111111, "Medium", "B", true);
    }).then(assert.fail).catch(function (error) {
      assert(error.message.indexOf('revert') >= 0, 'es correcto al estar activado el circuit breaker');
      })
    })
  


  //Al intentar registrar un paciente con el flag de emergencia activado y con la dirección 
  //de otra cuenta que no es el admin no se devuelve true
  it('Al intentar registrar un paciente con el flag de emergencia activado y con la dirección de otra cuenta que no es el admin no se devuelve true', function () {
    return Pacientes.deployed().then(function (instance) {
      var PacientesInstance = instance;
      return PacientesInstance.newInfo( 75, 125, 50, 6, 1350, 11111111, "Medium", "B", true, { from: admin });
    }).then(assert.fail).catch(function (error) {
      assert(error.message.indexOf('revert') >= 0, 'es correcto al estar activado el circuit breaker');
      })
  })

  
  //Se ejecuta bien la función get info
  it('Al intentar recuperar los datos de un paciente se realiza de forma correcta', function () {
    return Pacientes.deployed().then(function (instance) {
      var PacientesInstance = instance;
      return PacientesInstance.getInfo( 76921472, { from: admin });
    }).then(function (resultado) {
      assert.equal(resultado.logs.length, 1, 'Se registra el evento');
      assert.equal(resultado.logs[0].event, 'Consulta', 'Debe generarse le evento Consulta');

    })
  })

  
 //El proceso de borrado se ejecuta de manera correcta
 it('El proceso de borrado se realiza de manera correcta', function () {
  return Pacientes.deployed().then(function (instance) {
    var PacientesInstance = instance;
    return PacientesInstance.removeInfo(76921472 , false, { from: admin });
  }).then(function (resultado) {
    assert.equal(resultado.logs.length, 1, 'Se registra el evento');
    assert.equal(resultado.logs[0].event, 'Delete', 'Debe generarse le evento Borrado');
})
})

})